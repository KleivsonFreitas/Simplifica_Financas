-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: gestao_financeira
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` enum('receita','despesa') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_categoria_usuario` (`usuario_id`),
  CONSTRAINT `fk_categoria_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias_personalizadas`
--

DROP TABLE IF EXISTS `categorias_personalizadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias_personalizadas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` enum('receita','despesa') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#6366F1',
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_usuario_categoria` (`usuario_id`,`nome`),
  KEY `idx_usuario_tipo` (`usuario_id`,`tipo`),
  CONSTRAINT `categorias_personalizadas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_personalizadas`
--

LOCK TABLES `categorias_personalizadas` WRITE;
/*!40000 ALTER TABLE `categorias_personalizadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorias_personalizadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metas`
--

DROP TABLE IF EXISTS `metas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `titulo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `valor_alvo` decimal(10,2) NOT NULL,
  `valor_atual` decimal(10,2) DEFAULT '0.00',
  `categoria` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Outros',
  `data_inicio` date NOT NULL,
  `data_limite` date DEFAULT NULL,
  `cor` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#6366F1',
  `status` enum('ativa','concluida','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'ativa',
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_conclusao` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_status` (`usuario_id`,`status`),
  KEY `idx_data_limite` (`data_limite`),
  KEY `idx_metas_ativas` (`usuario_id`,`status`,`data_limite`),
  CONSTRAINT `metas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metas`
--

LOCK TABLES `metas` WRITE;
/*!40000 ALTER TABLE `metas` DISABLE KEYS */;
INSERT INTO `metas` VALUES (4,11,'VIAGEM','',100.00,0.00,'Viagem','2025-11-30',NULL,'#6366f1','ativa','2025-11-30 12:56:52',NULL);
/*!40000 ALTER TABLE `metas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transacoes`
--

DROP TABLE IF EXISTS `transacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `tipo` enum('receita','despesa') COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `descricao` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Outros',
  `data` date NOT NULL,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_data` (`usuario_id`,`data`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_transacoes_usuario_data` (`usuario_id`,`data` DESC),
  KEY `idx_transacoes_tipo` (`tipo`),
  KEY `idx_transacoes_relatorio` (`usuario_id`,`tipo`,`categoria`,`data`),
  CONSTRAINT `transacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transacoes`
--

LOCK TABLES `transacoes` WRITE;
/*!40000 ALTER TABLE `transacoes` DISABLE KEYS */;
INSERT INTO `transacoes` VALUES (20,7,'receita',1350.00,'SALARIO','Salario','2025-10-30','2025-11-16 15:22:27'),(23,10,'receita',1500.00,'SALARIO','Salário','2025-11-01','2025-11-17 20:53:43'),(24,10,'despesa',50.00,'LUZ','Moradia','2025-11-15','2025-11-17 20:55:24'),(25,7,'despesa',50.00,'LUZ','Moradia','2025-11-10','2025-11-17 21:06:57');
/*!40000 ALTER TABLE `transacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modo_interface` enum('simples','avancado') COLLATE utf8mb4_unicode_ci DEFAULT 'simples',
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ultimo_acesso` datetime DEFAULT NULL,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (7,'JOSE KLEIVSON DA SILVA FREITAS','kleivsonfreitas@hotmail.com','scrypt:32768:8:1$sojMHfQyPrEopJIt$cf94e6849a222fefa14d50a8c72213142fb852a7a3d3b76d2e83bc0fb7768dfcb1e97083ffcd44e1c997dba54c63f4eb06b9dfb0a089dab728d0959af3ad4239','simples','2025-11-16 12:20:19','2025-11-18 22:43:44','2025-11-16 14:47:03'),(10,'JOSE KLEIVSON DA SILVA FREITAS','kleivsonfreitas@gmail.com','scrypt:32768:8:1$4GAhB0SJd0NAO89M$d90faf6ca78bff0839e21670a0e57fac40dda4184e40c2e1d3fc198513d7e96da606f4f592cd187fe52692673a2d4dcdd72fe20314b8c996803ccbe89b36c910','avancado','2025-11-17 17:53:03','2025-11-17 17:53:08','2025-11-17 20:53:03'),(11,'Maria Silva','maria@email.com','scrypt:32768:8:1$wwz1AMImzqpgzRnQ$f3127310b41dce85d2ca9f0bb6b401776186527d1a496e5b766bc37a1c4b1259b92c8c6983bdea60b85a13addaa3721884d5380832eb1082231a93fd93cda0e7','simples','2025-11-19 21:30:29',NULL,'2025-11-20 00:30:29'),(12,'Carlos Souza','carlos@email.com','scrypt:32768:8:1$wwz1AMImzqpgzRnQ$f3127310b41dce85d2ca9f0bb6b401776186527d1a496e5b766bc37a1c4b1259b92c8c6983bdea60b85a13addaa3721884d5380832eb1082231a93fd93cda0e7','avancado','2025-11-19 21:30:29',NULL,'2025-11-20 00:30:29'),(16,'Teste Usuario','teste1764469284@teste.com','scrypt:32768:8:1$PeQjRERmPH6q6cqI$4b5ab24d9c80ca81667e2d962b546aecbfbd8e2316ab326e4181033d0c0d05f7398806bdec64fa3c548ad42f407273791bf7ddf91aae1c1d3c084fa6dd129edd','simples','2025-11-29 23:21:25',NULL,'2025-11-30 02:21:25'),(17,'Usuario Fluxo','fluxo1764469285@teste.com','scrypt:32768:8:1$Cjhav4TQHTOWDQ5U$989e899db08ca0776aaffed731ac77d01bb96f13a225ec2f3607e3fda9631a06c7144f003cf889f0010c67597b2bf5d801abd5ebf80dd903a3130032e777fb03','simples','2025-11-29 23:21:26',NULL,'2025-11-30 02:21:26');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'gestao_financeira'
--

--
-- Dumping routines for database 'gestao_financeira'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-30 20:14:04
